const MusicCard = () => {
  return <div>MusicCard</div>;
};

export default MusicCard;
