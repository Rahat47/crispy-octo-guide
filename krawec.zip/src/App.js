import "./App.css";
import Home from "./Pages/Home";

function App() {
  return (
    <div className="App bg-primary">
      <Home />
      {/* <Contact /> */}
      {/* <About /> */}
      {/* <Music /> */}
    </div>
  );
}

export default App;
